import { thisUser } from "../router";
import { MatchObject, saveMatch } from "../services/matchActions";
import { startTimer } from "../components/Timer";

export function initGameTournament(): void {
  const $ = (id: string) => document.getElementById(id)!;

  const paddle1 = $("paddle1");
  const paddle2 = $("paddle2");
  const ball = $("ball");
  const score1 = $("score1");
  const score2 = $("score2");
  const startPress = $("startPress");

  const paddleSfx = $("paddleSound") as HTMLAudioElement;
  const wallSfx = $("wallSound") as HTMLAudioElement;
  const lossSfx = $("lossSound") as HTMLAudioElement;

  // NEW: size matches GamePong2D CSS
  const FIELD = 100;
  const BALL_W = 3.3, BALL_H = 5;      // #ball: w-[3.3%], h-[5%]
  const PADDLE_W = 3.3, PADDLE_H = 25; // #paddle: w-[3.3%], h-[25%]

  let running = false;
  let animationFrameId = 0;

  let s1 = 0, s2 = 0;

  let p1Y = 37.5, p2Y = 37.5; // matches initial CSS top-[37.5%]
  let ballX = 50, ballY = 50;
  let ballVelX = 0, ballVelY = 0;

  let p1Vel = 0, p2Vel = 0;
  const accel = 0.5, maxSpeed = 2.5, friction = 0.1;

  let p1Up = false, p1Down = false, p2Up = false, p2Down = false;

// avoid stacking multiple keyboard listeners if init is called again
let __keysBound = false;

// utility: completely stop the loop
function stopGame() {
  running = false;
  if (animationFrameId) {
    cancelAnimationFrame(animationFrameId);
    animationFrameId = 0;
  }
}
(window as any).stopTournamentGame = stopGame;

(window as any).layoutTournamentRound = () => {
  // reset field & scores, show the "Press Space" text
  prepareNewRound();        // <- you already wrote this: stopGame + resetScores + resetObjects + show startPress
};

(window as any).beginTournamentRound = () => {
  // only start the actual round (no further resets)
  startTimer(5);
  serveBall();
  startGame();
};

// keep this convenience, but now it just calls the two-phase API
(window as any).startTournamentRound = () => {
  (window as any).layoutTournamentRound?.();
  (window as any).beginTournamentRound?.();
};
// reset ONLY positions & velocities (no scores)
function resetObjects() {
  p1Y = 37.5; p2Y = 37.5;
  p1Vel = 0;  p2Vel = 0;
  paddle1.style.top = p1Y + "%";
  paddle2.style.top = p2Y + "%";

  // place ball in center, no motion until we serve
  ballX = 50 - BALL_W / 2;
  ballY = 50 - BALL_H / 2;
  ballVelX = 0; ballVelY = 0;
  ball.style.left = ballX + "%";
  ball.style.top  = ballY + "%";
}

function resetScores() {
  s1 = 0; s2 = 0;
  score1.textContent = "0";
  score2.textContent = "0";
}

function prepareNewRound() {
  stopGame();
  resetScores();     // scores 
  resetObjects();    // paddles/ball
  startPress.classList.remove("hidden");
}

// serve the ball with fresh random direction
function serveBall() {
  const baseSpeedX = 1.2;
  const baseSpeedY = 0.8;
  ballVelX = Math.random() > 0.5 ? baseSpeedX : -baseSpeedX;
  ballVelY = Math.random() > 0.5 ? baseSpeedY : -baseSpeedY;
}

function startGame() {
  running = true;
  startPress.classList.add("hidden");
  // if for any reason the ball is stationary, (re)serve
  if (ballVelX === 0 && ballVelY === 0) serveBall();
  loop();
}

// public API the Tournament overlay calls EVERY round
(window as any).startTournamentRound = () => {
  prepareNewRound();    // full reset
  startTimer(5);        // 5-sec round
  serveBall();          // fresh serve
  startGame();          // begin loop
};


window.addEventListener("game:timeup", () => {
  stopGame();
  const timeUp = (window as any).tournamentTimeUp;
  if (typeof timeUp === "function") {
    timeUp(s1, s2); // tell TournamentFlow who is ahead
  }
});

	const overlayExit = document.getElementById("overlayExit");
	overlayExit?.addEventListener("click", () => {
		window.location.hash = "intro";
	});

  if (!__keysBound) {
	__keysBound = true;
	document.addEventListener("keydown", (e) => {
  if (e.code === "Space" && !running) {
    const ov = document.getElementById("tournament-overlay");
    if (ov && !ov.classList.contains("hidden")) return; // Space 1 handled by overlay

    // Space 2 (overlay is gone) -> start the round
    (window as any).beginTournamentRound?.();
  }
  if (e.key === "w") p1Up = true;
  if (e.key === "s") p1Down = true;
  if (e.key === "ArrowUp") p2Up = true;
  if (e.key === "ArrowDown") p2Down = true;
});

  document.addEventListener("keyup", (e) => {
    if (e.key === "w") p1Up = false;
    if (e.key === "s") p1Down = false;
    if (e.key === "ArrowUp") p2Up = false;
    if (e.key === "ArrowDown") p2Down = false;
  });
}

  function loop() {
    if (!running) return;
    updatePaddles();
    updateBall();
    animationFrameId = requestAnimationFrame(loop); //storeid
  }

  function updatePaddles() {
    p1Vel = applyInput(p1Up, p1Down, p1Vel);
    p2Vel = applyInput(p2Up, p2Down, p2Vel);

    // FIX: clamp to 100 - PADDLE_H (25%)
    const maxY = FIELD - PADDLE_H;
    p1Y = clamp(p1Y + p1Vel, 0, maxY);
    p2Y = clamp(p2Y + p2Vel, 0, maxY);

    paddle1.style.top = p1Y + "%";
    paddle2.style.top = p2Y + "%";
  }

  function applyInput(up: boolean, down: boolean, vel: number): number {
    if (up) vel -= accel;
    if (down) vel += accel;
    if (!up && !down) vel *= (1 - friction);
    return clamp(vel, -maxSpeed, maxSpeed);
  }

  function updateBall() {
    ballX += ballVelX;
    ballY += ballVelY;

    // FIX: walls consider BALL_H
    if (ballY <= 0) {
      ballY = 0;
      ballVelY *= -1;
      //playSound(wallSfx);
    } else if (ballY >= FIELD - BALL_H) {
      ballY = FIELD - BALL_H;
      ballVelY *= -1;
      //playSound(wallSfx);
    }

    // Paddle hitboxes with sizes
    // Left paddle: its right edge is at PADDLE_W, ball's left is ballX, right is ballX + BALL_W
    if (
      ballX <= PADDLE_W && // left side contact
      ballX + BALL_W >= 0 && // still within field
      ballY + BALL_H >= p1Y && ballY <= p1Y + PADDLE_H // vertical overlap
    ) {
      ballX = PADDLE_W; // resolve penetration
      ballVelX *= -1;
      //playSound(paddleSfx);
    }

    // Right paddle: its left edge is at FIELD - PADDLE_W
    if (
      ballX + BALL_W >= FIELD - PADDLE_W && // right side contact
      ballX <= FIELD && // still within field
      ballY + BALL_H >= p2Y && ballY <= p2Y + PADDLE_H // vertical overlap
    ) {
      ballX = FIELD - PADDLE_W - BALL_W; // resolve penetration
      ballVelX *= -1;
      //playSound(paddleSfx);
    }

    // FIX: symmetric scoring using the ball center
    const ballCenterX = ballX + BALL_W / 2;
    if (ballCenterX < 0) {
      s2++;
      score2.textContent = s2.toString();
      //playSound(lossSfx);
      resetBall();
    } else if (ballCenterX > FIELD) {
      s1++;
      score1.textContent = s1.toString();
      //playSound(lossSfx);
      resetBall();
    }

    ball.style.left = ballX + "%";
    ball.style.top = ballY + "%";
  }

  function resetBall() {
    ballX = 50 - BALL_W / 2;
    ballY = 50 - BALL_H / 2;
    // keep your faster settings or tweak here
    const baseSpeedX = 1.2;
    const baseSpeedY = 0.8;
    ballVelX = Math.random() > 0.5 ? baseSpeedX : -baseSpeedX;
    ballVelY = Math.random() > 0.5 ? baseSpeedY : -baseSpeedY;
  }

// TODO fix playsound function or delete from everywhere
//   function playSound(audio: HTMLAudioElement) {
//     audio.currentTime = 0;
//     audio.play();
//   }

  function clamp(val: number, min: number, max: number): number {
    return Math.max(min, Math.min(max, val));
  }

  // start clean (scores 0–0, centered)
	prepareNewRound();
}
