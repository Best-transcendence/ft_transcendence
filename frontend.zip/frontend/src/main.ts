import { router } from './router';

window.addEventListener('hashchange', router);
window.addEventListener('DOMContentLoaded', router);
